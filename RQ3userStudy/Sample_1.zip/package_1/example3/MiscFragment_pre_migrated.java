package com.grarak.kerneladiutor.fragments.kernel;

import android.content.Context;
import android.os.Vibrator;

import com.grarak.kerneladiutor.fragments.recyclerview.RecyclerViewFragment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class MiscFragment extends RecyclerViewFragment {

    private Vibration mVibration;

    private void vibrationInit(List<RecyclerViewItem> items) {
        final Vibrator vibrator = (Vibrator) getActivity()
                .getSystemService(Context.VIBRATOR_SERVICE);

        final int min = mVibration.getMin();
        int max = mVibration.getMax();
        final float offset = (max - min) / 100f;

        SeekBarView vibration = new SeekBarView();
        vibration.setTitle(getString(R.string.vibration_strength));
        vibration.setUnit("%");
        vibration.setProgress(Math.round((mVibration.get() - min) / offset));
        vibration.setOnSeekBarListener(new SeekBarView.OnSeekBarListener() {
            @Override
            public void onStop(SeekBarView seekBarView, int position, String value) {
                mVibration.setVibration(Math.round(position * offset + min), getActivity());
                getHandler().postDelayed(() -> {
                    if (vibrator != null) {
                         VibrationEffect vibe=VibrationEffect.createOneShot(300,VibrationEffect.DEFAULT_AMPLITUDE);
                         vibrator.vibrate(vibe);
                    }
                }, 250);
            }

            @Override
            public void onMove(SeekBarView seekBarView, int position, String value) {
            }
        });

        items.add(vibration);
    }

}
