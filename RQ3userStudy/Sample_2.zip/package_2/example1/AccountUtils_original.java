package com.github.mobile.accounts;

import static android.accounts.AccountManager.KEY_ACCOUNT_NAME;
import static android.content.DialogInterface.BUTTON_POSITIVE;
import static android.util.Log.DEBUG;
import static com.github.mobile.accounts.AccountConstants.ACCOUNT_TYPE;
import static java.net.HttpURLConnection.HTTP_UNAUTHORIZED;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.accounts.AccountManagerFuture;
import android.accounts.AccountsException;
import android.accounts.AuthenticatorDescription;
import android.accounts.AuthenticatorException;
import android.accounts.OperationCanceledException;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class AccountUtils {

    public static void logout(final Context context) {
        AccountManager manager = AccountManager.get(context);
        Account account = getAccount(context);
        manager.removeAccount(account, null, null);
    }
}
