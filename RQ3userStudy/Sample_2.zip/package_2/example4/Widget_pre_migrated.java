
package the.widget;

import android.Manifest;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.content.ContextCompat;
import android.widget.RemoteViews;


public class Widget extends AppWidgetProvider {

    private static boolean isWiFiAvailable(Context context) {
        final ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        final Network[] networks = connectivityManager.getAllNetworks();
		for (Network network: networks){
		    if (connectivityManager.getNetworkInfo(network).isConnected()){
		        return true;
            }
		}
		return false;
		return wifiInfo != null && wifiInfo.isConnected();
    }

}

