package ar.diwebapp;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.ActionBarActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.CookieManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;

public class PodsActivity extends ActionBarActivity {

    BroadcastReceiver podListReceiver;
    EditText filter;
    ListView lv;
    ImageView imgSelectPod;
    ProgressDialog progressDialog;
    private static final String TAG = "Diaspora Pods";

    public void askConfirmation(final String podDomain) {
        if (Helpers.isOnline(PodsActivity.this)) {
            new AlertDialog.Builder(PodsActivity.this)
                    .setTitle(getString(R.string.confirmation))
                    .setMessage(getString(R.string.confirm_pod)+podDomain+"?")
                    .setPositiveButton("YES",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {

                                    SharedPreferences sp = getSharedPreferences("PodSettings", MODE_PRIVATE);
                                    SharedPreferences.Editor editor = sp.edit();
                                    editor.putString("podDomain", podDomain);
                                    editor.apply();


                                        try {
                                            CookieManager.getInstance().removeAllCookies(null);
                                            CookieManager.getInstance().removeSessionCookies(null);
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }


                                    Intent i = new Intent(PodsActivity.this, MainActivity.class);
                                    dialog.cancel();
                                    startActivity(i);
                                    finish();
                                }
                            })
                    .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                        @TargetApi(11)
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    }).show();

        } else {
            Snackbar.make(getWindow().findViewById(R.id.podsLayout), R.string.no_internet, Snackbar.LENGTH_SHORT).show();
        }
    }

}


